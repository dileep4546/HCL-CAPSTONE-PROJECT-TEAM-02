import axios from "axios";

export async function getMessageApi(id){

    let result = await axios.get("http://localhost:8084/message/getbyuser/"+id);

    return  result.data;

}
export async function deleteMessage(id){

    let result = await axios.delete("http://localhost:8084/message/cancel/"+id);

    return  result.data;

}