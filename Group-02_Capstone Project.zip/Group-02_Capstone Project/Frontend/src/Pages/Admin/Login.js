import React,{useState} from 'react';
import {useNavigate} from 'react-router-dom'
import './Login.css'
import { LoginDetails } from '../../service/user-service';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
toast.configure();


function Login() {


      const notify = (msg) => {
        toast.success(msg, {
       position: 'top-right',
       autoClose: 3000,
        hideProgressBar: true,
          closeOnClick: false,
          auseOnHover: true,
          draggable: false,
           progress: undefined,
          theme: 'colored'
         });
        }
        const toastify = (msg) =>{
            toast.error(msg, {
                position: 'top-right',
                autoClose: 3000,
            hideProgressBar: true,
              closeOnClick: false,
              auseOnHover: true,
              draggable: false,
               progress: undefined,
              theme: 'colored'
             });
        }
    const navigate  = useNavigate();
    const handleSubmit=()=>{

        navigate('/register');
    }

    const [logindata,setLogin] = useState({
        aemail:''  ,
        adpassword:''
    })
    const handleloginChange=(e)=>{
        e.preventDefault();
        
        const fieldName = e.target.getAttribute('name');
        const fieldValue = e.target.value;

        const newFormData = {...logindata};
        newFormData[fieldName] = fieldValue;

        setLogin(newFormData);
    }
    async function submitLoginForm(e){

        e.preventDefault();
        console.log(logindata);    
       
        if(logindata.aemail.trim() === '' || logindata.adpassword.trim() === ''){
            notify("give proper information!");
            
            return;
        }

        LoginDetails(logindata).then((res)=>{
  

            console.log(res);
            if(res === "Invalid user"){

                toastify(res)
                navigate('/login');
            }
            else{
                localStorage.setItem("AdminUser",res)
                notify(res +" Login suceesfully")
                navigate('/home');
            }
           
        })
        .catch(error =>{
            console.log(error);
        })
    }
    const handleWelcome =()=>{
        navigate("/")
   }
   
 




    return (
        <div id='admin-login'>
                <div className='Login-page mt-5'>

                    <h3 className='mt-5'>Admin Login</h3>
                <form  onSubmit={submitLoginForm} id="submitted"  className='Login-form mt-5'>
                    
                    <div className='mb-3'>
                            <label className='form-label' htmlFor='aemail'>
                            Email
                            </label>
                            <input className='form-control' type="email"id="aemail" name="aemail" placeholder='abc@gmailcom'
                                 onChange={handleloginChange}
                            required/>
                    </div>

                    <div className='mb-3'>
                        <label className='form-label' htmlFor='adpassword'>
                            Password
                        </label>
                        <input className='form-control' type="password" id="adpassword" name="adpassword" placeholder='password'
                                 onChange={handleloginChange}  
                        required/>

                    </div>

                            <button className='btn btn-success mt-5' 
                            >Login</button>
                            <span>
                             <button className='btn btn-danger mt-5' 
                               onClick={handleWelcome}
                               style={{marginLeft:"10px"}} >Cancel</button>
                            </span>
                            <h6 className='mt-5' 
                                onClick={handleSubmit}
                            > Not member? Register here</h6>
                </form>
        </div>
                   
                 
                </div>
    );
}

export default Login;