import React from 'react';
import { useState } from 'react';
import { signUp } from '../../service/user-service';
import {useNavigate} from 'react-router-dom'
import { toast } from 'react-toastify';
import './Login.css'
import 'react-toastify/dist/ReactToastify.css';
toast.configure();

function Register() {
      const notify = (msg) => {
        toast.success(msg, {
            position: 'top-right',
            autoClose: 3000,
        hideProgressBar: true,
          closeOnClick: false,
          auseOnHover: true,
          draggable: false,
           progress: undefined,
          theme: 'colored'
         });
        }

    const navigate  = useNavigate();
    const handleLogin=()=>{

        navigate('/login');
    }

    const [reg,setRegisterData] = useState({
        aname:'',
        aemail:'',
        adpassword:''
    })

    const handleChange=(e)=>{
        e.preventDefault();
        
        const fieldName = e.target.getAttribute('name');
        const fieldValue = e.target.value;

        const newFormData = {...reg};
        newFormData[fieldName] = fieldValue;

        setRegisterData(newFormData);
    }
    
    async function submitForm(e){

        e.preventDefault();
        // console.log(reg);    
        if(reg.aemail.trim() === '' || reg.adpassword.trim() === '' || reg.aname.trim() === ''){
            notify("give proper information!");
            // toast.error("please!!!!!!!")
            return;
        }


        signUp(reg).then((resp)=>{
            console.log(resp,"Added");
            notify("Register Successfully..")

            navigate('/login');
        })
        .catch(error =>{
            console.log(error);
        })
    }



    return (
        <div className='Register-page'>
            <div className='Login-page '>

               <h3 className='mt-3'>Admin Register</h3>
                    <form  onSubmit={submitForm}   className='Login-form mt-3'>
                    <div className='mb-3'>
                            <label className='form-label' htmlFor='aname'>
                            Name
                            </label>
                            <input className='form-control' type="text"id="aname" name="aname" placeholder='abc@gmailcom'
                                onChange={handleChange}
                            required/>
                    </div>
                    <div className='mb-3'>
                            <label className='form-label' htmlFor='aemail'>
                            Email
                            </label>
                            <input className='form-control' type="email"id="aemail" name="aemail" placeholder='abc@gmailcom'
                                onChange={handleChange}
                            required/>
                    </div>

                    <div className='mb-3'>
                        <label className='form-label' htmlFor='adpassword'>
                            Password
                        </label>
                        <input className='form-control' type="password"id="adpassword" name="adpassword" placeholder='password'
                                onChange={handleChange}  
                        required/>

                    </div>

                            <button className='btn btn-danger mt-3' 
                            //   onClick={handleSubmit}
                            >Register</button>
                            <h6 className='mt-3' 
                                onClick={handleLogin}
                            > Login here</h6>
                        
                    </form>
            </div>
        </div>
    );
}

export default Register;