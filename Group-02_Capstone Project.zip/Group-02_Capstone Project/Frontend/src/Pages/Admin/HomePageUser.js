import React from 'react';
import HeaderUser from '../../Components/Admin/AdminHeader';
import Home1 from '../../Components/Admin/Home';




function HomePageUser1(props) {
    return (
        <>
        <div>
            <HeaderUser/>

            <Home1/>
            
            
        </div>
        
        </>
        
    );
}

export default HomePageUser1;