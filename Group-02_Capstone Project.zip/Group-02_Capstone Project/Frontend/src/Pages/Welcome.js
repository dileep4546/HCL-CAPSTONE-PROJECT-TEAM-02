import React from 'react';
import {useNavigate} from 'react-router-dom'
import './Welcome.css'

function HomePage() {
    const navigate  = useNavigate();
    const handleAdmin=()=>{

        navigate('/login');
    }

    const handleUser=()=>{

        navigate('/loginUser');
    }
     return (
    <div id='Welcome-page'>
        <div class="row main ">
            
        <h1>WELCOME TO FRACTO</h1>
        
        <div class="column">
     
         <p>
         <img src="https://th.bing.com/th/id/OIP.8lEw7JhbgcP_85Iom0Z7ZAHaH0?pid=ImgDet&rs=1" onClick={handleAdmin} alt=""/>     
         <h2 className='wel-usere'>ADMIN</h2>
         </p>
       
      </div>
       <h2><span >HEALTH IS WEALTH</span></h2>
       <div class="column">   
       <p>
    
         <img src="https://png.pngtree.com/png-vector/20190130/ourlarge/pngtree-cute-cartoon-little-girl-medical-patient-wearing-sick-suit-servicegirlmedicalpatient-png-image_631453.jpg" onClick={handleUser} alt=""/>    
         <h2 className='wel-usere'>USER</h2>
        </p>
        
        
   
       </div>
     
      </div>
      </div>
      

      
      
      );
     }
    


export default HomePage;