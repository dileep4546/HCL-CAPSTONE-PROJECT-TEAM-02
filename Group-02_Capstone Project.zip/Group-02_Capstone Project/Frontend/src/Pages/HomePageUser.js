import React from 'react';
import Nav from '../Components/User/Nav/Nav'
import Home from '../Components/User/Home'
import Footer from '../Components/Footer/Footer';

function HomePageUser(props) {
    return (

        <>

       
        <div>
            <Nav/>

            <Home/>

            
            
        </div>
        <div class="card">
  <div class="card-header">
    
  </div>
  <div class="card-body">
    <blockquote class="blockquote mb-0">
      <img src='https://entrackr.com/wp-content/uploads/2018/01/practo-image-2-1200x600.jpg'></img>
      <p>"Prevention is better than cure"</p>
      <footer class="blockquote-footer">Desiderius Erasmus <cite title="Source Title"></cite></footer>
    </blockquote>
  </div>
</div>

<Footer/>





      
        
        </>
    );
}

export default HomePageUser;