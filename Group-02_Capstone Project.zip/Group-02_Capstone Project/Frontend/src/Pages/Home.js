import React from 'react';
import UserCrud from '../Components/Admin/UserCrud'
import HeaderUser from '../Components/Admin/AdminHeader';

function Home() {
    return (
        <div>
        
                <div className="">
                    <HeaderUser/>
                    <div>
                        <UserCrud/>
                    </div>
                </div>
           
        </div>
    );
}

export default Home;