import React,{useState} from 'react';
import {useNavigate} from 'react-router-dom'
import './Login.css'
import { LoginDetailsUser } from '../../service/user-service';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
toast.configure();

function Login() {
      const notify = (msg) => {
        toast.success(msg, {
            position: 'top-right',
            autoClose: 3000,
        hideProgressBar: true,
          closeOnClick: false,
          auseOnHover: true,
          draggable: false,
           progress: undefined,
          theme: 'colored'
         });
        }

        const toastify = (msg) =>{
            toast.error(msg, {
                position: 'top-right',
                autoClose: 3000,
            hideProgressBar: true,
              closeOnClick: false,
              auseOnHover: true,
              draggable: false,
               progress: undefined,
              theme: 'colored'
             });
        }

    const navigate  = useNavigate();
    const handleSubmit=()=>{

        navigate('/registerUser');
    }

    const [logindata,setLogin] = useState({
        pemail:''  ,
        password:''
    })
    const handleloginChange=(e)=>{
        e.preventDefault();
        
        const fieldName = e.target.getAttribute('name');
        const fieldValue = e.target.value;

        const newFormData = {...logindata};
        newFormData[fieldName] = fieldValue;

        setLogin(newFormData);
    }
    async function submitLoginForm(e){

        e.preventDefault();
        console.log(logindata);    
       
        if(logindata.pemail.trim() === '' || logindata.password.trim() === ''){
            notify("give proper information!");
            // toast.error("please!!!!!!!")
            return;
        }

        LoginDetailsUser(logindata).then((res)=>{
           
            if(res === "invalid user"){

                toastify(res )
                navigate('/loginUser');
            }
            else{
                localStorage.setItem("LoginUser",res)
                notify(res +" Login suceesfully")
                navigate('/homeUser');
            }
           
           
        })
        .catch(error =>{
            console.log(error);
        })
    }

   const handleWlecome =()=>{
        navigate("/")
   }

    return (
        <div id='LoginUser'>
                <div className='Login-page ' >

                    <h3 className='mt-5'>User Login</h3>
                <form  onSubmit={submitLoginForm}   className='Login-form mt-5'>
                    
                    <div className='mb-3'>
                            <label className='form-label' htmlFor='pemail'>
                            Email
                            </label>
                            <input className='form-control' type="email"id="pemail" name="pemail" placeholder='abc@gmailcom'
                                 onChange={handleloginChange}
                            required/>
                    </div>

                    <div className='mb-3'>
                        <label className='form-label' htmlFor='password'>
                            Password
                        </label>
                        <input className='form-control' type="password" id="password" name="password" placeholder='password'
                                 onChange={handleloginChange}  
                        required/>

                    </div>

                       <span>     
                             <button className='btn btn-success mt-5'  style={{marginRight:"10px"}} >Login</button>
                        </span>
                        <span>
                             <button className='btn btn-danger mt-5' 
                               onClick={handleWlecome}
                            >Clear</button>
                            </span>
                            <h6 className='mt-5' 
                                onClick={handleSubmit}
                            > Not a user? Register here</h6>
                </form>
        </div>
                   
                 
                </div>
    );
}

export default Login;