import React from 'react';
import { useState } from 'react';
import { signUpUser } from '../../service/user-service';
import {useNavigate} from 'react-router-dom'
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
toast.configure();

function RegisterUser() {

      const notify = (msg) => {
        toast.success(msg, {
            position: 'top-right',
            autoClose: 3000,
            hideProgressBar: true,
          closeOnClick: false,
          auseOnHover: true,
          draggable: false,
           progress: undefined,
          theme: 'colored'
         });
        }

    const navigate  = useNavigate();
    const handleLogin=()=>{

        navigate('/loginUser');
    }

    const [reg,setRegisterData] = useState({
        pname:'',
        pemail:'',
        password:''
    })

    const handleChange=(e)=>{
        e.preventDefault();
        
        const fieldName = e.target.getAttribute('name');
        const fieldValue = e.target.value;

        const newFormData = {...reg};
        newFormData[fieldName] = fieldValue;

        setRegisterData(newFormData);
    }
    
    async function submitForm(e){

        e.preventDefault();
        if(reg.pemail.trim() === '' || reg.password.trim() === '' || reg.pname.trim() === ''){
            notify("give proper information!");
            // toast.error("please!!!!!!!")
            return;
        }

        signUpUser(reg).then((resp)=>{
            console.log(resp,"Added");
            notify("Register Successfully..")

            navigate('/loginUser');
        })
        .catch(error =>{
            console.log(error);
        })
    }



    return (
        <div className='Register-page'>
            <div className='Login-page '>

               <h3 className='mt-3'>User Register</h3>
                    <form  onSubmit={submitForm}   className='Login-form mt-3'>
                    <div className='mb-3'>
                            <label className='form-label' htmlFor='pname'>
                            Name
                            </label>
                            <input className='form-control' type="text"id="pname" name="pname" placeholder='UserName'
                                onChange={handleChange}
                            required/>
                    </div>
                    <div className='mb-3'>
                            <label className='form-label' htmlFor='pemail'>
                            Email
                            </label>
                            <input className='form-control' type="email"id="pemail" name="pemail" placeholder='abc@gmailcom'
                                onChange={handleChange}
                            required/>
                    </div>

                    <div className='mb-3'>
                        <label className='form-label' htmlFor='password'>
                            Password
                        </label>
                        <input className='form-control' type="password"id="password" name="password" placeholder='password'
                                onChange={handleChange}  
                        required/>

                    </div>

                            <button className='btn btn-danger mt-3' 
                            //   onClick={handleSubmit}
                            >Register</button>
                            <h6 className='mt-3' 
                                onClick={handleLogin}
                            > Login here?</h6>
                        
                    </form>
            </div>
        </div>
    );
}

export default RegisterUser;