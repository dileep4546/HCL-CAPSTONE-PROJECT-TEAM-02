import { Button, Table, TableBody, TableCell, TableHead, TableRow } from "@mui/material";
import { makeStyles } from "@emotion/styled";
import React, { useState, useEffect } from "react";
import { deleteMessage, getMessageApi } from "../../service/message-service";

const useStyle = makeStyles({
  table: {
    width: "80%",
    margin: "50px 100px 100px 140px",
   },
  thead: {
     "& > *": {
       background: "blue",
       color: "#FFFFFF",
       fontSize: "16px",
     },
   },
   trow: {
     "& > *": {
       fontSize: "16px",
     },
   },
 });

 export default function Message() {
   const [getMessage, setgetMessage] = useState([])
  const getMessageDetails = async () => {
     let data = await getMessageApi(Number(localStorage.getItem("user_id")));    
     setgetMessage(data);

   }

   useEffect(() => {
     getMessageDetails();
   }, [])




   const deleteData = async (id) => {

     await deleteMessage(id);
     getMessageDetails();

   };


   const classes = useStyle();
   return (
     <>
       <Table className={classes.table}>
        <TableHead>
           <TableRow className={classes.thead}>
             <TableCell>ID</TableCell>
             <TableCell>Message</TableCell>

            <TableCell></TableCell>
           </TableRow>
         </TableHead>
         <TableBody>
           {getMessage.map((data) => (
            <TableRow className={classes.trow}>
             <TableCell>{data.mes_id}</TableCell>
              <TableCell>{data.message}</TableCell>

               <TableCell>


                 <Button
                   variant="contained"
                   color="secondary"
                   style={{ margin: "0px 20px" }}
                 onClick={() => deleteData(data.mes_id)}
                 >
                  Cancel
                 </Button>
              </TableCell>

            </TableRow>

           ))}

         </TableBody>
       </Table>
     </>
   );
 }
