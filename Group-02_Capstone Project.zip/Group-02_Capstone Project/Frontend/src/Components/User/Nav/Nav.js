import React, { Component } from 'react';
import { NavLink } from "react-router-dom";
import './Nav.css'

class Nav extends Component {


    render() {
        return (
            <div>
                <div className="navigation" style={{filter: "drop-shadow(2px 4px 6px cadetblue)"}}>
      <nav className="navbar navbar-expand navbar-dark bg-dark">
        <div className="container">
          <NavLink className="navbar-brand bgcolor" to="/">
           <img src="https://www.moja-dejavnost.si/Fracto-d-o-o.PNG.png?type=Logo&p=bdb5c7aa40d049f88f41f54f0d21247a.png" alt="" style={{height:"50px"}} />
          </NavLink>
          <NavLink className="navbar-brand bgcolor" to="/homeUser">
                <span className='welcome'>WELCOME, {localStorage.getItem("LoginUser")}</span>
          </NavLink>
          <div>
            <ul className="navbar-nav ml-auto">
              <li className="nav-item">
                <NavLink className="nav-link bgcolor" to="/homeUser">
                  Home
                  <span className="sr-only"></span>
                </NavLink>
              </li>
              <li className="nav-item ">
                <NavLink className="nav-link bgcolor" to="/findDoctors">
                Find Doctors
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink className="nav-link bgcolor" to="/Medicine">
                     Medicines
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink className="nav-link bgcolor" to="/status">
                      Status
                </NavLink>
              </li>
              
              <li className="nav-item">
                <NavLink className="nav-link bgcolor"  to="/"
                style={{    backgroundColor: "cadetblue",
                 borderRadius: "5px",color:"white",filter: "drop-shadow(2px 4px 6px black)"}}>
                      Logout
                </NavLink>
              </li>
            </ul>
          </div>
        </div>
      </nav>
           </div>
            </div>
        );
    }
}


export default Nav;