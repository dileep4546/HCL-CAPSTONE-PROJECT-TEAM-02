import React,{useState} from 'react';
import Nav from './Nav/Nav';
import './Style.css'
import {Status} from "../../service/user-service"
import { FaSearch } from "react-icons/fa";
import axios from 'axios';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
toast.configure();


function FindDoctors() {

    const notify = (msg) => {
        toast.success(msg, {
            position: 'top-right',
            autoClose: 3000,
        hideProgressBar: true,
          closeOnClick: false,
          auseOnHover: true,
          draggable: false,
           progress: undefined,
          theme: 'colored'
         });
        }

        const notify1 = (msg) => {
            toast.error(msg, {
                position: 'top-right',
                autoClose: 3000,
            hideProgressBar: true,
              closeOnClick: false,
              auseOnHover: true,
              draggable: false,
               progress: undefined,
              theme: 'colored'
             });
            }
    const [users, setUser] = useState([]);
    
      const [find , setFind] =useState({
        ap_id:'',
      
    })

    const {ap_id} = find;

    const handleChange = (e) =>{

        setFind({...find,[e.target.name]: e.target.value})
    }

    const handleSubmit = (e) =>{
        e.preventDefault();
        console.log(find);

        Status(find).then((res)=>{

            console.log(res,"eeeeeeeeee");
         
            if(res == ''){
                notify1("Not found");
            }
            setUser(res);
        })
    }
   
    const  deleteUser = async ap_id =>{

        alert("Are you sure you want to delete the Appointment.")
         await axios.delete(`http://localhost:8082/app/delete/${ap_id}`);
         notify("Appintment Id: "+ap_id+" Cancelled Successfully" );
        

     }
  
    return (
        <div className='status'>
            <Nav/>
            <div>
            <form onSubmit={handleSubmit}>

                <span className='city'>
                <input type="search" placeholder='Enter Appointment ID' className='mt-5' name="ap_id" value={ap_id}   onChange={e => handleChange(e)}/>
                <FaSearch/>
                </span>
                
                <button className='find-subButton btn btn-primary mr-5'>Search</button>
            </form>
            <div className="container find-doctors">
                 <div className="py-4">
                <h2>Find Your Appointment Status</h2>
             
                <div class="table border shadow" style={{  marginTop: "10px",
                    background: "white",
                        opacity: "0.7"}}>
                                
                    <div className="row find-lind mt-3">
                        <div className="col-md-4">
                            <img src="https://secureservercdn.net/198.71.233.68/m7w.e22.myftpupload.com/wp-content/uploads/2020/02/make-an-appointment.png" width={200}></img>
                        </div>
                        <div className="col-md-8 find-doctor-6 mt-3">
                            <div className="row ">
                              <span><b>Appointment Id:</b></span><span>{users.ap_id}</span>     <br />   
                           </div>
                           <div className="row">
                             <span>Dr.Name:</span><span><b>{users.dname}</b></span>        <br />   
                           </div>
                           <div className="row">
                             <span>Patient Name:</span><span><b>{users.pname}</b></span>        <br />   
                           </div>      
                           <div className="row">
                                 <span><b>Date:</b></span><span>{users.date} </span> <br />   
                           </div>
                           <div className="row">
                                 <span><b>Time:</b></span><span>{users.time}  </span> <br />   
                           </div>
                           <div className="row">
                              <span><b>Status:</b></span><span>{users.status}</span> <br />
                           </div> 
                           <div className="">
                           <button className='find-subButton btn btn-primary mr-5'
                             onClick={() => deleteUser(users.ap_id)}>Cancel Appointment</button>
                           </div> 
                        </div>

                    </div>
                
                   
                </div>
            </div>
            </div>
            </div>
        </div>
    );
}

export default FindDoctors;