import React from 'react';
import './Home.css'
import {useNavigate}  from 'react-router-dom'

function Service() {

  const navigate = useNavigate();
  const handlefindDoctors = () =>{
    navigate("/findDoctors")
  }
  const handleMedicines = () =>{
    navigate("/Medicine")
  }

  return (

    <div id='home-user-A'>
        
       <div className='row mt-5' style={{width:"100%"}}>
     <div class="card homecard">
      
        <div class="card-body column">
               <div className='card '>
               <div class="card-title"><b>Instant Video Consultation</b></div>
               <div class="card-img-top">
              <img src="https://static.wixstatic.com/media/45cd64_03e3e0e676f740e8865a455e7871e97b~mv2_d_2136_2000_s_2.png/v1/fill/w_490,h_459,al_c,usm_0.66_1.00_0.01/45cd64_03e3e0e676f740e8865a455e7871e97b~mv2_d_2136_2000_s_2.png" aalt="Mountains" onClick={handlefindDoctors} style={{backgroundColor:"#AFCFED" ,width:"250px",cursor:"pointer"}}/>
              </div>
                 <div class="card-text"><b>Connect within secs</b></div>
               </div>     
        </div>
         <div class="card-body column">
               <div className='card '>
               <div class="card-title"><b>Find Doctors Near You</b></div>
               <div class="card-img-top">
              <img src="https://www.practostatic.com/consumer-home/desktop/images/1597423628/dweb_find_doctors.png" alt="Mountains" onClick={handlefindDoctors} style={{backgroundColor:"#98CBD6" ,width:"81%",cursor:"pointer"}}/>
              </div>
               
                 <div class="card-text"><b>Take Appoinment</b></div>
              
               </div>
              
        </div>
            <div class="card-body column">
               <div className='card ' >
               <div class="card-title"><b>Medicines</b></div>
               <div class="card-img-top">
              <img src="https://www.practostatic.com/consumer-home/desktop/images/1597423628/dweb_medicines.png" alt="Mountains" onClick={handleMedicines} style={{backgroundColor:"#CCD0DB" ,width:"86%",cursor:"pointer"}}/>
              </div>
             
                 <div class="card-text" style={{fontsize:"15px"}}><b>Essentials at your doorstep</b></div>
        
               </div>
              
        </div>
         <div class="card-body column">
               <div className='card '>
               <div class="card-title"><b>Lab Test</b></div>
               <div class="card-img-top">
              <img src="https://www.practostatic.com/consumer-home/desktop/images/1597423628/dweb_lab_tests.png" onClick={handleMedicines} alt="Mountains" style={{backgroundColor:"#AFCFED" ,width:"100%",cursor:"pointer"}}/>
              </div>
               
                 <div class="card-text" style={{fontsize:"13px"}}><b>Sample pickup at your home</b></div>
              
               </div>
              
        </div>
         <div class="card-body column">
               <div className='card'>
               <div class="card-title"><b>Surgeries</b></div>
               <div class="card-img-top">
              <img src="https://www.practostatic.com/consumer-home/desktop/images/1597423628/dweb_surgeries.png" onClick={handlefindDoctors} alt="Mountains" style={{backgroundColor:"#D5D8FC" ,width:"250px",cursor:"pointer"}}/>
              </div>
             
                 <div class="card-text" ><b>Safe and trusted surgery centers</b></div>
            
               </div>
              
        </div>
          </div>
      </div>
      <div className='container mt-3'>
          <h1>Book an appointment for an in-clinic consultation</h1>
          <p>Find experienced doctors across all specialties</p>
        <div className='column'>
         <img  src="https://www.practostatic.com/consumer-home/desktop/images/1558283618/sp-dentist@2x.jpg" style={{width:"250px"}}/>
         <div>
         <h3>Dentist</h3>
          <p>Teething troubles? Schedule a dental checkup</p>
         </div>
        </div>
        <div className='column'>
         <img  src="https://www.practostatic.com/consumer-home/desktop/images/1558283618/sp-gynecologist@2x.jpg"  style={{width:"250px"}} />
      <div>
      <h3>Gynecologist</h3>
        <p>Explore for women’s health, pregnancy and infertility treatments</p>
      </div>
        </div>

        <div className='column'>
         <img src="https://www.practostatic.com/consumer-home/desktop/images/1558283618/sp-dietitian@2x.jpg" style={{width:"250px"}} />
         <div>
          <h3>Dietitian</h3>
        <p>Get guidance on eating right, weight management and sports nutrition</p>
      </div>
        </div>
        <div className='column'>
         <img  src="https://www.practostatic.com/consumer-home/desktop/images/1558283618/sp-physiotherapist@2x.jpg"  style={{width:"250px"}} />
         <div>
         <h3>Physiotherapist</h3>
        <p>Pulled a muscle? Get it treated by a trained physiotherapist</p>
      </div>
      
        </div>
      </div>
      
    </div>

);
}

export default Service;