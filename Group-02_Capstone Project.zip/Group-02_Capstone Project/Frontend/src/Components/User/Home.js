import React from 'react';
import './Home.css'
import {useNavigate}  from 'react-router-dom'
function Home() {

  const navigate = useNavigate();
  const handlefindDoctors = () =>{
    navigate("/findDoctors")
  }
  const handleMedicines = () =>{
    navigate("/Medicine")
  }
 
  return (

    <h1>WELCOME TO FRACTO</h1>

   
);
}

export default Home;