import React from 'react';
import './Home.css'
import {useNavigate}  from 'react-router-dom'

function Home1() {

  const navigate = useNavigate();
  const handlefindDoctors = () =>{
    navigate("/findDoctors1")
  }
  const handleMedicines = () =>{
    navigate("/Medicine1")
  }

  return (

   <div>
    <h1> welcome to fracto</h1>
   </div>
   
    

);
}

export default Home1;