import React,{useState,useEffect} from 'react';
import './Style.css'
import { Link } from "react-router-dom";
import {DoctorData} from "../../service/user-service"
import { FaSearch,FaRupeeSign ,FaThumbsUp, FaCalendar} from "react-icons/fa";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import HeaderUser from './AdminHeader';
import "bootstrap/dist/css/bootstrap.min.css";
import { getList } from './list';
import Footer from '../Footer/Footer';
toast.configure();


function FindDoctors1() {
    const [searchKey, setSearchKey] = useState("");
    const [list, setList] = useState([]);
    const notify = (msg) => {
        toast.error(msg, {
            position: 'top-right',
            autoClose: 3000,
        hideProgressBar: true,
          closeOnClick: false,
          auseOnHover: true,
          draggable: false,
           progress: undefined,
          theme: 'colored'
         });
        }
    const [users, setUser] = useState([]);
    
      const [find , setFind] =useState({
        city:'',
        profession:'',
        date:''
    })

    const {city,profession,date} = find;

    const handleChange = (e) =>{

        setFind({...find,[e.target.name]: e.target.value})
    }

    const handleSubmit = (e) =>{
        e.preventDefault();
        console.log(find);

        DoctorData(find).then((res)=>{
            
            if(res == ''){
                notify("Data Not found")
            }

            setUser(res);

        })
    }

    useEffect(() => {
        let mounted = true;
         getList()
        .then(items => {
          if(mounted){
            setList(items)
          }
        })
        return () => mounted = false;
      }, [])

    return (
        <>
        <div className='find'>
            <HeaderUser/>
            
            <h1>
                FIND YOUR DOCTOR
                
            </h1>
            <div className='find-docters'>
            <form onSubmit={handleSubmit}>

                <span className='city'>
                   <input type="search" placeholder='Choose City' className='mt-5' name="city" value={city}   onChange={e => handleChange(e)}/>
                   <FaSearch/>
                </span>&nbsp;
                <span className='city'>
                    <input type="search" placeholder='Specialization' className='mt-5' name='profession' value={profession} onChange={e => handleChange(e)}/>
                    <FaSearch/>
                </span>&nbsp;
                <span className='city'>
                <input type="date" placeholder='Date' className='mt-5' name='date' value={date} onChange={e => handleChange(e)}/>
             
                </span>
                <button className='find-subButton btn btn-primary mr-5'>FIND</button>
            </form>
            <div className="container find-doctors">
                 <div className="py-4">
                 <div class="table border shadow find-table">
                <h2>YOUR SEARCH RESULT</h2>
                {users.map((data) => (
                    <div className="row find-lind mt-3">
                        <div className="col-md-4">
                            <img src={data.img} width={170}></img>
                        </div>
                        <div className="col-md-6 find-doctor-6 mt-5">
                            <div className="row ">
                              {/* <span>ID:</span><span>{data.d_id}</span>     <br />    */}
                           </div>
                           <div className="row">
                             <span style={{    textDecoration: "underline",color: "blue"}}><b>{data.dname}</b></span>        <br />   
                           </div>
                           <div className="row">
                                 <span>{data.profession} </span> <br />   
                           </div>
                           <div className="row">
                              <span>{data.exp} Years Experience </span> <br />
                           </div>       
                           <div className="row">
                                 <span>{data.address} </span> <br />   
                           </div>
                           <div className="row">
                               <span><FaRupeeSign/>{data.fees} Consultation fee</span> <br />   
                           </div>
                           <div className="row ">
                             <span className='find-rating'><FaThumbsUp/> {data.rating} </span> <br />   
                           </div>
                         
                        </div>
                        <div className="col-md-2">
                            <div >
                                <Link
                                    class="btn btn-book " 
                                    to={`/bookAppointment1/${data.d_id}`}
                                    >
                                    <button>Book Appointment</button>
                                </Link>
                            </div>
                            <div className="container" style={{backgroundColor:""}}>
                                    <FaCalendar/>
                                    <span> Availabilty</span> <br />
                                   <strong style={{color: "darkblue"}}> {data.date}</strong> 
                            </div>
                         </div>
                    </div>
                    ))}
                   
                </div>
                <h2>Available Doctors</h2>
                <div class="table border shadow find-table">
		<form className="table-bordered" style={{margin:"50px"}}  >
			<table align="center" width={"100%"} border="1px solid">
		  <thead>
		   
			          {/* <th><b>DOCTOR ID</b></th>
					  <th><b>DOCTOR NAME</b></th>
                      <th><b>DOCTOR CITY</b></th>
			          <th><b>EXPERIENCE</b></th>
                      <th><b>DOCTOR FEES</b></th>
                      <th><b>DOCTOR PROFESSION</b></th>
                      <th><b>AVAILABLE DATE</b></th>
					  <th><b>DOCTOR RATING</b></th>
					  <th><b>DOCTOR IMAGE</b></th>
			 */}
			</thead>
			
			{list.map(doctor =>
			<tr>
			  <td key={doctor.id}><b>{doctor.id}</b></td>
			  <td><b>{doctor.name}</b></td>
			  <td><b>{doctor.city}</b></td>
			  <td><b>{doctor.exp}</b></td>
              <td><b>{doctor.fee}</b></td>
              <td><b>{doctor.prof}</b></td>
              <td><b>{doctor.date}</b></td>
              <td><b>{doctor.rate}</b></td>
			  <td ><img height='250px' width='250px' src={doctor.image}/></td>
			</tr>
			)}
		  
		  </table>
		  </form>
          
		  
	  </div>
                
               
            </div>
            </div>
            </div>
            
           
        </div>
        <Footer/>
        </>
    );
}

export default FindDoctors1;