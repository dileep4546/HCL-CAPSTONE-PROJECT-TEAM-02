import React from 'react';
import { useState } from 'react';
import './Style.css'
import {DoctorData} from "../../service/user-service"
import HeaderUser from './AdminHeader';

function Medicine1(props) {

    const [find , setFind] =useState({
        city:'',
        profession:'',
        date:''
    })
   


    const {city,profession,date} = find;

    const handleChange = (e) =>{

        setFind({...find,[e.target.name]: e.target.value})

    }

    const handleSubmit = (e) =>{
        e.preventDefault();
        // console.log(find);
        DoctorData(find).then((jwtTokenData)=>{
  
            // console.log(jwtTokenData,"ppppppppppppppppp");
           
        })
    }

   

    return (
        <>
       <h1>Get your medicines</h1>
       
       </>
    );
}

export default Medicine1;