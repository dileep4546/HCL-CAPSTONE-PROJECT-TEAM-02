export function getList() {
    return fetch('http://localhost:3333/doctor')
    .then(data => data.json())
}