import { cyan } from '@mui/material/colors'
import React from 'react'
import Login from '../../src/Pages/Admin/Login'





describe('<Login />', () =>{
    it('renders', ()=>{
        cy.mount(<Login />)
        cy.contains("Admin Login").should('be.visible').and('have.text','Admin Login');
    })
}
)
