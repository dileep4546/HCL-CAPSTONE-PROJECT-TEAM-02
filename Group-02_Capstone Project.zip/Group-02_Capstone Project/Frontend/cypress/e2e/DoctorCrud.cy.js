describe('DoctorCrud', () => {
    it('Doctor Crud', () => {
      cy.visit('http://localhost:3000/doctorCrud')
    })
  })