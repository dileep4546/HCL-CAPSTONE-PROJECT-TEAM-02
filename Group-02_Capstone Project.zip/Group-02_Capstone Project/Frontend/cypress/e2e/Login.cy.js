describe('Login page', () => {
  it('Login page', () => {
    cy.visit('http://localhost:3000/loginUser')
  })
})