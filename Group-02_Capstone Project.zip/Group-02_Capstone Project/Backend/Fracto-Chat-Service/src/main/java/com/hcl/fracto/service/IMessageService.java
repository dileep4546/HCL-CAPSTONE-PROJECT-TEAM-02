package com.hcl.fracto.service;

import java.util.List;

import com.hcl.fracto.dto.MessageDTO;



public interface IMessageService {
	public MessageDTO sendMessage( MessageDTO messageDTO);

	public List<MessageDTO> getMessage();

}
