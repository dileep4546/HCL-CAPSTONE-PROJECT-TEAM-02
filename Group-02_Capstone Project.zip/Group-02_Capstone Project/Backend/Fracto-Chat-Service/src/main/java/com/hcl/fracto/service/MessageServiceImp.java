package com.hcl.fracto.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.fracto.dto.MessageDTO;
import com.hcl.fracto.entity.Message;
import com.hcl.fracto.repository.MessageRepository;

@Service
public class MessageServiceImp implements IMessageService {

	@Autowired
	MessageRepository repo;

	@Override
	public MessageDTO sendMessage(MessageDTO messageDTO) {

		Message message = new Message();
		message.setMessage(messageDTO.getMessage());
		message.setFromUser(messageDTO.getFromUser());
		message = repo.save(message);

		messageDTO.setFromUser(message.getFromUser());
		messageDTO.setMessage(message.getMessage());

		return messageDTO;
	}

	@Override
	public List<MessageDTO> getMessage() {

		List<MessageDTO> data = new ArrayList<MessageDTO>();

		List<Message> messages = repo.findAll();
		for (Message message : messages) {

			MessageDTO messageDTO = new MessageDTO();
			messageDTO.setFromUser(message.getFromUser());
			messageDTO.setMessage(message.getMessage());
			data.add(messageDTO);

		}

		return data;
	}

}
