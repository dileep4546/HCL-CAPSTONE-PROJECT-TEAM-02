package com.hcl.fracto.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.fracto.dto.MessageDTO;
import com.hcl.fracto.service.MessageServiceImp;

@RestController
@RequestMapping("/api/chat")
@CrossOrigin("*")
public class MessageRestController {

	@Autowired
	MessageServiceImp service;

	@PostMapping("/sendMessage")
	public MessageDTO sendMessage(@RequestBody MessageDTO messageDTO) {
		return service.sendMessage(messageDTO);
	}

	@GetMapping("/getMessage")
	public List<MessageDTO> getMessage() {
		return service.getMessage();
	}

}
