package com.hcl.fracto.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.fracto.entity.Appointment;

import com.hcl.fracto.exceptions.AppointmentNotFoundException;
import com.hcl.fracto.repository.AppointmentRepository;

@Service            //Business logic are written in @service 
public class AppointmentServiceImp implements IAppointmentService {

	@Autowired
	AppointmentRepository appointmentRepo;

	@Override
	public Appointment bookAppointment(Appointment appointment) {
		// TODO Auto-generated method stub
		return appointmentRepo.save(appointment);
	}

	@Override
	public List<Appointment> findAll() {
		// TODO Auto-generated method stub
		return appointmentRepo.findAll();
	}

	@Override
	public Optional<Appointment> findById(long ap_id) throws AppointmentNotFoundException {
		try {
			return appointmentRepo.findById(ap_id);
		} catch (Exception e) {
			// throwing exception if user does not exist
			throw new AppointmentNotFoundException("invalid apointment Id");
		}
	}

	@Override
	public String update(Appointment appointment, long ap_id) {
		Appointment res = appointmentRepo.findById(ap_id).get();

		res.setDname(appointment.getDname());
		res.setPname(appointment.getPname());
		res.setMobNo(appointment.getMobNo());
		res.setDate(appointment.getDate());
		res.setTime(appointment.getTime());
		res.setStatus(appointment.getStatus());

		appointmentRepo.save(res);
		return "Update Successfully";
	}

	@Override
	public String cancleAppointment(long ap_id) throws AppointmentNotFoundException {

		try {
			appointmentRepo.deleteById(ap_id);

			return "Appointment cancled Successfully";
		} catch (Exception e) {
			// throwing exception if user does not exist
			throw new AppointmentNotFoundException("invalid application Id");
		}
	}

	@Override
	public Appointment FindByApID(Appointment appointment) {
		List<Appointment> res = appointmentRepo.findAll();

		for (Appointment ad : res) {
			if (ad.getAp_id() == appointment.getAp_id()) {

				return ad;
			}
		}
		return null;
	}

}
