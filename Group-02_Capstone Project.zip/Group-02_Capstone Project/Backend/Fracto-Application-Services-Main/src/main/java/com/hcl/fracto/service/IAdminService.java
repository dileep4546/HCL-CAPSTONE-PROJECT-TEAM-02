package com.hcl.fracto.service;

import java.util.List;
import java.util.Optional;

import com.hcl.fracto.entity.Admin;
import com.hcl.fracto.exceptions.AdminNotFoundException;

public interface IAdminService {
	
	public Admin addAdmin(Admin admin);
	
	public List<Admin> getAll();
	
	public Optional<Admin> findbyId(long a_id) throws AdminNotFoundException;
	
	public String update_Admin(Admin admin, long a_id);
	
	public String delete_Admin(long a_id) throws AdminNotFoundException;
	
	public String login_Admin(Admin admin);

}
