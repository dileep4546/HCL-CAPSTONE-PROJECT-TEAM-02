package com.hcl.fracto.restcontroller;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.fracto.entity.Doctor;
import com.hcl.fracto.exceptions.DoctorNotFoundException;
import com.hcl.fracto.service.DoctorServiceImp;

@RestController                  //@RestController is used to create restful web services
@RequestMapping("/doctor")       //@RequestMapping is used to map web requests onto specific handler classes 
@CrossOrigin(origins = "http://localhost:3000")                //@Cross origin allows restricting the resources implemented in web browsers
public class DoctorController {

	@Autowired
	DoctorServiceImp doctorService; //for automatic dependency injection of DoctorServiceImp

	

	@GetMapping("/findAll")
	public List<Doctor> findAll() {
		//Finding all doctors

		return doctorService.findAll();
	}

	//PostMapping is used to add 
	@PostMapping("/save")
	public Doctor save(@RequestBody Doctor doctor) {

		return doctorService.addDoctor(doctor);
	}

	@GetMapping("/findById/{d_id}")
	public Optional<Doctor> findById(@PathVariable long d_id) throws DoctorNotFoundException {
		//To find doctor by giving doctor id

		return doctorService.findById(d_id);
	}

	@PutMapping("/Update/{d_id}")
	public Doctor Update(@RequestBody Doctor doctor, @PathVariable long d_id) {
		//update doctor by giving doctor id

		return doctorService.Update(doctor, d_id);
	}

	//To delete doctor by id
	@DeleteMapping("/delete/{d_id}")
	public String delete(@PathVariable long d_id) throws DoctorNotFoundException {

		return doctorService.delete(d_id);
	}
	
	//To find doctor by ratin

	@PostMapping("/findByPro")
	public List<Doctor> findByPro(@RequestBody Doctor doctor) {


		return doctorService.findByPro(doctor);



	}
}
