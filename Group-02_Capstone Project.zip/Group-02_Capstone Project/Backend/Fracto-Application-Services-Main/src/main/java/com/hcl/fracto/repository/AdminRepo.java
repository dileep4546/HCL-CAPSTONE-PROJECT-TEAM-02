package com.hcl.fracto.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.fracto.entity.Admin;

public interface AdminRepo extends JpaRepository<Admin, Long> {

}