package com.hcl.fracto.service;

import java.util.List;
import java.util.Optional;

import com.hcl.fracto.entity.Doctor;
import com.hcl.fracto.exceptions.DoctorNotFoundException;

public interface IDoctorService {

	public Doctor addDoctor(Doctor doctor);

	public List<Doctor> findAll();

	public Optional<Doctor> findById(long d_id) throws DoctorNotFoundException;

	public Doctor Update(Doctor doctor, long d_id);

	public List<Doctor> findByPro(Doctor doctor);
	
	public String delete(long d_id) throws DoctorNotFoundException;

}
