package com.hcl.fracto.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data

public class Message {
	
	
	private String fromUser;
	
	private String message;

}
