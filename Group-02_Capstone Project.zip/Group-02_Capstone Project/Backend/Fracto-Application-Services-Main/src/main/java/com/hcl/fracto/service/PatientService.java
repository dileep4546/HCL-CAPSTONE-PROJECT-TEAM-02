package com.hcl.fracto.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import com.hcl.fracto.entity.Patient;
import com.hcl.fracto.repository.PatientRepo;
import com.hcl.fracto.vo.Message;

import lombok.var;

@Service
public class PatientService implements IPatientService {

	@Autowired
	PatientRepo patientRepo;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	RestTemplate restTemplate;

	@Override
	public Patient registerPatient(Patient patient) {

		return patientRepo.save(patient);

	}

	// @Override
	public String loginPatient(Patient login) {
		List<Patient> patient = patientRepo.findAll();
		for (Patient ad : patient) {

			if (ad.getPemail().equalsIgnoreCase(login.getPemail())
					&& ad.getPassword().equalsIgnoreCase(login.getPassword())) {

				return ad.getPname();
			}
		}
		return "invalid user";
	}

	@Override
	public List<Patient> findAll() {
		// TODO Auto-generated method stub
		return patientRepo.findAll();
	}

	@Override
	public Optional<Patient> findByID(long p_id) {
		// TODO Auto-generated method stub
		return patientRepo.findById(p_id);
	}

	@Override
	public String delete_Patient(long p_id) {
		patientRepo.deleteById(p_id);
		return "Deleted Successfully";
	}

	@Override
	public String updatePatient(Patient patient, long p_id) {
		Patient res = patientRepo.findById(p_id).get();

		res.setPname(patient.getPname());
		res.setPemail(patient.getPemail());
		res.setPassword(patient.getPassword());

		patientRepo.save(res);
		return "Update Successfully";
	}

	@Override
	public Message sendMessage(Message msg) {

		String url = "http://localhost:8084/api/chat/sendMessage";
		var headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		@var
		org.springframework.http.HttpEntity<java.lang.String> entity;
		try {
			entity = new HttpEntity<>(mapper.writeValueAsString(msg), headers);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ResponseEntity<Message> responseEntity = restTemplate.postForEntity(url, msg, Message.class);
		Message response = responseEntity.getBody();
		return response;

	}

}
