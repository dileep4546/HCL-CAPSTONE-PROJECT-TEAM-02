package com.hcl.fracto.service;

import java.util.List;
import java.util.Optional;

import com.hcl.fracto.entity.Appointment;
import com.hcl.fracto.exceptions.AppointmentNotFoundException;

public interface IAppointmentService {

	public Appointment bookAppointment(Appointment appointment);

	public List<Appointment> findAll();

	public Optional<Appointment> findById(long ap_id) throws AppointmentNotFoundException;

	public String update(Appointment appointment, long ap_id);

	public String cancleAppointment(long ap_id) throws AppointmentNotFoundException;

	public Appointment FindByApID(Appointment appointment);

}
