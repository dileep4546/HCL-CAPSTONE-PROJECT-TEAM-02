package com.hcl.fracto.exceptions;

public class AdminNotFoundException extends Exception{
	
	public AdminNotFoundException(String message) {

		super(message);
	}

	
	

}
