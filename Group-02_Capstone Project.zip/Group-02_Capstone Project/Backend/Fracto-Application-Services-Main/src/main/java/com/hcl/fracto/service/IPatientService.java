package com.hcl.fracto.service;

import java.util.List;
import java.util.Optional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hcl.fracto.entity.Patient;
import com.hcl.fracto.vo.Message;

public interface IPatientService {
	
	public Patient registerPatient(Patient patient);
	
	public String loginPatient(Patient login);
	
	public List<Patient> findAll();
	
	public Optional<Patient> findByID(long p_id);
	
	public String updatePatient(Patient patient, long p_id); 
	
	public String delete_Patient(long p_id); 
	
	public Message sendMessage(Message msg) throws JsonProcessingException;

}
