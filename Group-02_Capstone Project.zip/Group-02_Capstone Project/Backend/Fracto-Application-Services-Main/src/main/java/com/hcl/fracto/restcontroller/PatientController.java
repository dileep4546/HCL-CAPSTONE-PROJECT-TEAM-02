package com.hcl.fracto.restcontroller;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.hcl.fracto.entity.Patient;
import com.hcl.fracto.service.PatientService;

@RestController
@RequestMapping("/patient")
@CrossOrigin(origins = "http://localhost:3000")
public class PatientController {

	@Autowired
	PatientService patientService;

//	@GetMapping("/get")
//	public String getdata() {
//
//		return "Heloo";
//	}

	@PostMapping("/register")
	public Patient register_Patient(@RequestBody Patient patient) {

		return patientService.registerPatient(patient);
	}

//	@PostMapping

	@PostMapping("/login")
	public String login_Patient(@RequestBody Patient login) {

		System.out.println(login + "ooo");
		return patientService.loginPatient(login);
	}

	@GetMapping("/findAll")
	public List<Patient> findAll() {
		return patientService.findAll();
	}

	@GetMapping("/findByID/{p_id}")
	public Optional<Patient> findByID(@PathVariable Long p_id) {

		return patientService.findByID(p_id);
	}

	@PutMapping("/update/{p_id}")
	public String update_Patient(@RequestBody Patient patient, @PathVariable long p_id) {

		return patientService.updatePatient(patient, p_id);
	}

	@DeleteMapping("/delete/{p_id}")
	public String delete_Patient(@PathVariable long p_id) {

		return patientService.delete_Patient(p_id);
	}
}
