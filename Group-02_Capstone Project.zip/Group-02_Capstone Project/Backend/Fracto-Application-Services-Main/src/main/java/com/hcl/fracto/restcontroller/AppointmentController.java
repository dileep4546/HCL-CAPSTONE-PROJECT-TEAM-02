package com.hcl.fracto.restcontroller;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.fracto.entity.Appointment;
import com.hcl.fracto.exceptions.AppointmentNotFoundException;
import com.hcl.fracto.service.AppointmentServiceImp;

@RestController
@RequestMapping("/app")
@CrossOrigin(origins = "http://localhost:3000")
public class AppointmentController {

	@Autowired
	AppointmentServiceImp appointmentService;

	@GetMapping("/findAll")
	public List<Appointment> findAll() {

		return appointmentService.findAll();
	}

	@PostMapping("/save")
	public Appointment save(@RequestBody Appointment appointment) {

		return appointmentService.bookAppointment(appointment);
	}

	@GetMapping("/findById/{ap_id}")
	public Optional<Appointment> findById(@PathVariable long ap_id) throws AppointmentNotFoundException {

		return appointmentService.findById(ap_id);
	}

	@PutMapping("/update/{ap_id}")
	public String update(@RequestBody Appointment appointment, @PathVariable long ap_id) {

		return appointmentService.update(appointment, ap_id);
	}

	@DeleteMapping("/delete/{ap_id}")
	public String delete(@PathVariable long ap_id) throws AppointmentNotFoundException {

		return appointmentService.cancleAppointment(ap_id);
	}

	@PostMapping("/FindByApID")
	public Appointment FindByApID(@RequestBody Appointment appointment) {

		return appointmentService.FindByApID(appointment);
	}
}
