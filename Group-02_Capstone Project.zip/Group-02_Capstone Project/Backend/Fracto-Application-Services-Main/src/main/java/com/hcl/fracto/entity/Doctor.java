package com.hcl.fracto.entity;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data

@Entity
@Table(name = "doctor")
public class Doctor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long d_id;
	
	@NotBlank(message = "provide doctor name")
	private String dname;

	@NotBlank(message = "provide doctor experiance")
	private long exp;

	@NotBlank(message = "provide doctor address")
	private String address;

	@NotBlank(message = "provide doctor city")
	private String city;

	@NotBlank(message = "provide doctor fees")
	private long fees;

	@NotBlank(message = "provide doctor profession")
	private String profession;

	@NotBlank(message = "provide doctor img")
	private String img;

	@NotBlank(message = "provide doctor date")
	private String date;

	@NotBlank(message = "provide doctor rating")
	private long rating;

}
