package com.hcl.fracto.exceptions;

public class DoctorNotFoundException extends Exception {
	
	public DoctorNotFoundException(String message) {

		super(message);
	}

}
