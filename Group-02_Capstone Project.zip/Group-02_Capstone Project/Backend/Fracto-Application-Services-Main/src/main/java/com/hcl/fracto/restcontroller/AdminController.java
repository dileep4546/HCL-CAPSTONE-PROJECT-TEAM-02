package com.hcl.fracto.restcontroller;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.fracto.entity.Admin;
import com.hcl.fracto.exceptions.AdminNotFoundException;
import com.hcl.fracto.service.AdminServiceImp;

@RestController                   //@RestController is used to create restful web services

@RequestMapping("/admin")         //@RequestMapping is used to map web requests onto specific handler classes 
@CrossOrigin(origins = "http://localhost:3000")                  //@Cross origin allows restricting the resources implemented in web browsers
public class AdminController {

	@Autowired
	AdminServiceImp adminService;  //for automatic dependency injection of AdminServiceImp

	@GetMapping("/get")
	public List<Admin> getAll() {

		return adminService.getAll();
	}

	@PostMapping("/register")
	public Admin addAdmin(@RequestBody Admin admin) {

		return adminService.addAdmin(admin);
	}

	@GetMapping("/findbyId/{a_id}")
	public Optional<Admin> findbyId(@PathVariable long a_id) throws AdminNotFoundException {

		return adminService.findbyId(a_id);
	}

	@PutMapping("/update/{a_id}")
	public String update_Admin(@RequestBody Admin admin, @PathVariable long a_id) {

		return adminService.update_Admin(admin, a_id);
	}

	@DeleteMapping("/delete/{a_id}")
	public String delete_Admin(@PathVariable long a_id) throws AdminNotFoundException {

		return adminService.delete_Admin(a_id);
	}

	@PostMapping("/login")
	public String login_Admin(@RequestBody Admin admin) {

		return adminService.login_Admin(admin);
	}
}
