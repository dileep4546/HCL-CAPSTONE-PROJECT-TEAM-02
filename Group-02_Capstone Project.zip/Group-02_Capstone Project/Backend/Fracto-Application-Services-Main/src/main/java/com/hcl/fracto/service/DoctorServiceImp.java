package com.hcl.fracto.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.JpaSort;
import org.springframework.stereotype.Service;

import com.hcl.fracto.entity.Doctor;
import com.hcl.fracto.exceptions.DoctorNotFoundException;
import com.hcl.fracto.repository.DoctorRepository;

@Service
public class DoctorServiceImp implements IDoctorService {

	@Autowired
	DoctorRepository doctorRepo;

	@Override
	public Doctor addDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		return doctorRepo.save(doctor);
	}

	@Override
	public List<Doctor> findAll() {
		// TODO Auto-generated method stub
		return doctorRepo.findAll();
	}

	@Override
	public Optional<Doctor> findById(long d_id) throws DoctorNotFoundException {
		// TODO Auto-generated method stub
		try {
		return doctorRepo.findById(d_id);
		}
		catch(Exception e) {
			//throwing exception if user does not exist
			throw new DoctorNotFoundException("sorry! no doctor avilable for your disesase");
		}
		
	}

	@Override
	public Doctor Update(Doctor doctor, long d_id) {
		Doctor res = doctorRepo.findById(d_id).get();
		//
		res.setDname(doctor.getDname());
		res.setAddress(doctor.getAddress());
		res.setCity(doctor.getCity());
		res.setExp(doctor.getExp());
		res.setFees(doctor.getFees());
		res.setProfession(doctor.getProfession());
		res.setImg(doctor.getImg());
		res.setDate(doctor.getDate());
		res.setRating(doctor.getRating());

		return doctorRepo.save(res);
	}

	@Override
	public List<Doctor> findByPro(Doctor doctor) {

		List<Doctor> res = doctorRepo.findAll(JpaSort.by("rating").descending());
		List<Doctor> res1 = new ArrayList<>();

		for (Doctor ad : res) {

			if (ad.getCity().equalsIgnoreCase(doctor.getCity()) && ad.getDate().equalsIgnoreCase(doctor.getDate())
					&& ad.getProfession().equalsIgnoreCase(doctor.getProfession())) {

				res1.add(ad);
			}
		}

		return res1;
	}

	@Override
	public String delete(long d_id) throws DoctorNotFoundException {
		

		try {
		doctorRepo.deleteById(d_id);
		return "Deleted Successfully";
		}
		catch(Exception e) {
			//throwing exception if user does not exist
			throw new DoctorNotFoundException("sorry! no doctor avilable for your disesase");
		}

	}

}
