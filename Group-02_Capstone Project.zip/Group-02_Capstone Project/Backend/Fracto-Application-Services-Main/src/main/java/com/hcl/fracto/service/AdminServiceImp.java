package com.hcl.fracto.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.fracto.entity.Admin;
import com.hcl.fracto.exceptions.AdminNotFoundException;

import com.hcl.fracto.repository.AdminRepo;

@Service
public class AdminServiceImp implements IAdminService {

	@Autowired
	AdminRepo adminRepo;

	@Override
	public Admin addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminRepo.save(admin);
	}

	@Override
	public List<Admin> getAll() {
		// TODO Auto-generated method stub
		return adminRepo.findAll();
	}

	@Override
	public Optional<Admin> findbyId(long a_id) throws AdminNotFoundException {
		try {
			return adminRepo.findById(a_id);
		} catch (Exception e) {
			// throwing exception if user does not exist
			throw new AdminNotFoundException("invalid admin Id");
		}
	}

	@Override
	public String update_Admin(Admin admin, long a_id) {

		Admin res = adminRepo.findById(a_id).get();
		//
		res.setAname(admin.getAname());
		res.setAemail(admin.getAemail());
		res.setAdpassword(admin.getAdpassword());

		adminRepo.save(res);
		return "Update Successfully";

	}

	@Override
	public String delete_Admin(long a_id) throws AdminNotFoundException {

		try {
			adminRepo.deleteById(a_id);

			return "Delete Successfully";
		} catch (Exception e) {
			// throwing exception if user does not exist
			throw new AdminNotFoundException("invalid admin Id");
		}
	}

	@Override
	public String login_Admin(Admin admin) {
		List<Admin> res = adminRepo.findAll();
		for (Admin ad : res) {

			if (ad.getAemail().equalsIgnoreCase(admin.getAemail())
					&& ad.getAdpassword().equalsIgnoreCase(admin.getAdpassword())) {

				return ad.getAname();
			}
		}
		return "Invalid user";
	}


}
