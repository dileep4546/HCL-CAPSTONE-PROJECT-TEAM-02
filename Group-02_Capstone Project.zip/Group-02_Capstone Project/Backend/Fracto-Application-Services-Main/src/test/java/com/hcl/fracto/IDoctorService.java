package com.hcl.fracto;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class IDoctorService {

}

