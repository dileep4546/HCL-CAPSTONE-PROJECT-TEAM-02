package com.hcl.fracto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hcl.fracto.entity.Patient;
import com.hcl.fracto.service.IPatientService;

@SpringBootTest
class FractoServiceApplicationTests {

	@Autowired
	IPatientService service;

	@Test
	void contextLoads() {
	}

	@Test
	void testRegisterPatient() {

		Patient pat = new Patient();
		// pat.setP_id(3);
		pat.setPname("ram");
		pat.setPemail("ram@gmail.com");
		pat.setPassword("ram");

		Patient pat1 = service.registerPatient(pat);
		assertEquals("ram", pat1.getPname());

	}
	
	@Test
	void testDeletePatientById() {
		service.delete_Patient(1);
		Optional<Patient> pat = service.findByID(1);
		assertNull(pat);
	}
	

}
