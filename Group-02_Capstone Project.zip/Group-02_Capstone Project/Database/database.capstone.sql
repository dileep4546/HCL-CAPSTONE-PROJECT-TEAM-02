create database fracto9;
use fracto9;
show tables;
#to see the admin details
select  * from admin;

#to see the doctor details
select * from doctor;

#to see the patient or user details
select * from patient;

#to see the appointment details
select * from appointment;

#to see the messages sent by admin
select * from message;